import React, { useState } from 'react';
import { Trash2, Users, CheckSquare, Square, AlertTriangle } from 'lucide-react';
import { Student } from '../../types';
import { storage } from '../../services/storageService';

export interface LearnerManagerProps {
  learners: Student[];
  setLearners: React.Dispatch<React.SetStateAction<Student[]>> | ((learners: Student[]) => void);
  onInspect?: (id: string) => void;
}

export default function LearnerManager({ learners, setLearners, onInspect }: LearnerManagerProps) {
  // Array storing IDs of checked learners
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Toggle single selection
  const handleSelectOne = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  // Toggle "Select All"
  const handleSelectAll = () => {
    if (selectedIds.length === learners.length && learners.length > 0) {
      setSelectedIds([]); // Deselect all
    } else {
      setSelectedIds(learners.map(item => item.id)); // Select all
    }
  };

  // Execute Deletion for Selected Learners
  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;

    if (window.confirm(`Are you sure you want to delete ${selectedIds.length} selected learner(s)?`)) {
      // 1. Filter out deleted learners from UI state
      const updatedList = learners.filter(item => !selectedIds.includes(item.id));
      setLearners(updatedList);

      // 2. Persist to storage (localStorage / EduHub Storage & SQLite backup)
      storage.bulkDeleteStudents(selectedIds);
      try {
        localStorage.setItem('eduhub_learners', JSON.stringify(updatedList));
      } catch (e) {
        // ignore
      }

      // 3. Reset selection array
      const count = selectedIds.length;
      setSelectedIds([]);
      alert(`Selected ${count} learner(s) removed successfully!`);
    }
  };

  const isAllSelected = learners.length > 0 && selectedIds.length === learners.length;

  return (
    <div className="p-4 sm:p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-slate-900 dark:text-white">
              Learner Directory ({learners.length})
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Select one or multiple learners to manage enrollment or perform bulk deletions
            </p>
          </div>
        </div>

        {/* Bulk Action Delete Button */}
        {selectedIds.length > 0 && (
          <button 
            onClick={handleDeleteSelected}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md shadow-rose-600/30 transition-all cursor-pointer animate-fadeIn"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete Selected ({selectedIds.length})</span>
          </button>
        )}
      </div>

      {/* Selection Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 uppercase font-black tracking-wider text-[10px] border-b border-slate-200 dark:border-slate-800">
              <th className="p-3.5 w-12 text-center">
                <input 
                  type="checkbox" 
                  aria-label="Select all learners"
                  className="w-4 h-4 rounded-md text-emerald-600 focus:ring-emerald-500 border-slate-300 dark:border-slate-700 cursor-pointer"
                  checked={isAllSelected} 
                  onChange={handleSelectAll} 
                />
              </th>
              <th className="p-3.5">Name</th>
              <th className="p-3.5">Grade</th>
              <th className="p-3.5">Gender</th>
              <th className="p-3.5">Admission No.</th>
              {onInspect && <th className="p-3.5 text-right">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
            {learners.length === 0 ? (
              <tr>
                <td colSpan={onInspect ? 6 : 5} className="p-8 text-center text-slate-500 dark:text-slate-400">
                  No learners found in the directory.
                </td>
              </tr>
            ) : (
              learners.map((student) => {
                const isSelected = selectedIds.includes(student.id);
                return (
                  <tr 
                    key={student.id} 
                    className={`transition-colors ${
                      isSelected 
                        ? 'bg-rose-50/60 dark:bg-rose-950/20' 
                        : 'hover:bg-slate-50/80 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="p-3.5 text-center">
                      <input 
                        type="checkbox" 
                        aria-label={`Select ${student.name}`}
                        className="w-4 h-4 rounded-md text-emerald-600 focus:ring-emerald-500 border-slate-300 dark:border-slate-700 cursor-pointer"
                        checked={isSelected} 
                        onChange={() => handleSelectOne(student.id)} 
                      />
                    </td>
                    <td className="p-3.5 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-black text-[10px] flex items-center justify-center">
                        {student.name.charAt(0)}
                      </div>
                      <span>{student.name}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 text-[10px] font-bold">
                        {student.grade}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-400">{student.gender}</td>
                    <td className="p-3.5 font-mono text-slate-600 dark:text-slate-400">{student.admissionNumber}</td>
                    {onInspect && (
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => onInspect(student.id)}
                          className="px-2.5 py-1 text-xs font-bold text-rose-600 hover:text-rose-700 dark:text-rose-400 underline cursor-pointer"
                        >
                          Inspect
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Selected Items Summary Footer */}
      {selectedIds.length > 0 && (
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
          <span>{selectedIds.length} of {learners.length} learner(s) currently selected</span>
          <button
            onClick={() => setSelectedIds([])}
            className="text-slate-500 hover:text-slate-800 dark:hover:text-white text-xs underline cursor-pointer"
          >
            Clear selection
          </button>
        </div>
      )}
    </div>
  );
}

export { LearnerManager };
